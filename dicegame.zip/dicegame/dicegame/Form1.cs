﻿using System;
using System.Windows.Forms;

namespace dicegame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static int maxscore1;
        public static string playern1;
        public static string playern2;
        public static string playern3;
        public static string playern4;
        Boolean a;
        public static int plnum;
        public static int mxscore;

        private void button1_Click(object sender, EventArgs e)
        {
            play.Visible = true;
            try
            {
                int numPlay = Convert.ToInt32(playernum.Text);
                int maxscore2 = Convert.ToInt32(maxscore.Text);
                if (Convert.ToInt32(playernum.Text) == 1)
                {
                    MessageBox.Show("Min and max number of players 2 and 4", "ERROR",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Enter only numbers!!", "Unknown values");
                a = true;
            }

            if (a != true)
            {
                if (Convert.ToInt32(maxscore.Text) > 10 && Convert.ToInt32(maxscore.Text) < 1000)
                {
                    maxscore1 = Convert.ToInt32(maxscore.Text);
                }
                else if (Convert.ToInt32(maxscore.Text) == 0)
                {
                    MessageBox.Show("Please enter a number", "ERROR",
                   MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Score must be betwenn 10 and 1000", "ERROR",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                mxscore = Convert.ToInt32(maxscore.Text);
                switch (Convert.ToInt32(playernum.Text))
                {
                    case 2:
                        player1.Visible = true;
                        player2.Visible = true;
                        player3.Visible = false;
                        player4.Visible = false;
                        break;
                    case 3:
                        player1.Visible = true;
                        player2.Visible = true;
                        player3.Visible = true;
                        player4.Visible = false;
                        break;
                    case 4:
                        player1.Visible = true;
                        player2.Visible = true;
                        player3.Visible = true;
                        player4.Visible = true;
                        break;
                    default:
                        MessageBox.Show("Max number of players 4", "ERROR",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                }
                plnum = Convert.ToInt32(playernum.Text);
            }
            else
            {
                a = false;
            }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(playernum.Text)==2 && (name1.Text == "" || name2.Text == ""))
            {
                MessageBox.Show("Please nter your name", "Empty",
                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Convert.ToInt32(playernum.Text) == 3 && (name1.Text == "" || name2.Text == "" || name3.Text == ""))
            {
                MessageBox.Show("Please nter your name", "Empty",
                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Convert.ToInt32(playernum.Text) == 4 && (name1.Text == "" || name2.Text == "" || name3.Text == ""|| name4.Text == ""))
            {
                MessageBox.Show("Please nter your name", "Empty",
                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            { 
                playern1 = name1.Text;
                playern2 = name2.Text;
                playern3 = name3.Text;
                playern4 = name4.Text;
                this.timer1.Start();
                play.Hide();
                progressBar1.Show();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(10);
            if (progressBar1.Value >= progressBar1.Maximum)
            {
                timer1.Stop();
                this.Hide();
                Form2 fr2 = new Form2();
                fr2.ShowDialog();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            progressBar1.Hide();
        }
    }
}
