﻿
namespace dicegame
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.bank1 = new System.Windows.Forms.Label();
            this.score1 = new System.Windows.Forms.Label();
            this.players1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bank2 = new System.Windows.Forms.Label();
            this.score2 = new System.Windows.Forms.Label();
            this.players2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bank3 = new System.Windows.Forms.Label();
            this.score3 = new System.Windows.Forms.Label();
            this.players3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bank4 = new System.Windows.Forms.Label();
            this.score4 = new System.Windows.Forms.Label();
            this.players4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.wturn = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.bank1);
            this.panel1.Controls.Add(this.score1);
            this.panel1.Controls.Add(this.players1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(38, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 120);
            this.panel1.TabIndex = 0;
            // 
            // bank1
            // 
            this.bank1.AutoSize = true;
            this.bank1.Location = new System.Drawing.Point(21, 81);
            this.bank1.Name = "bank1";
            this.bank1.Size = new System.Drawing.Size(51, 18);
            this.bank1.TabIndex = 2;
            this.bank1.Text = "Bank:";
            // 
            // score1
            // 
            this.score1.AutoSize = true;
            this.score1.Location = new System.Drawing.Point(21, 49);
            this.score1.Name = "score1";
            this.score1.Size = new System.Drawing.Size(58, 18);
            this.score1.TabIndex = 1;
            this.score1.Text = "Score:";
            // 
            // players1
            // 
            this.players1.AutoSize = true;
            this.players1.Location = new System.Drawing.Point(64, 11);
            this.players1.Name = "players1";
            this.players1.Size = new System.Drawing.Size(102, 18);
            this.players1.TabIndex = 0;
            this.players1.Text = "Name player";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.Controls.Add(this.bank2);
            this.panel2.Controls.Add(this.score2);
            this.panel2.Controls.Add(this.players2);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Location = new System.Drawing.Point(533, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 120);
            this.panel2.TabIndex = 1;
            this.panel2.Visible = false;
            // 
            // bank2
            // 
            this.bank2.AutoSize = true;
            this.bank2.Location = new System.Drawing.Point(24, 81);
            this.bank2.Name = "bank2";
            this.bank2.Size = new System.Drawing.Size(51, 18);
            this.bank2.TabIndex = 5;
            this.bank2.Text = "Bank:";
            // 
            // score2
            // 
            this.score2.AutoSize = true;
            this.score2.Location = new System.Drawing.Point(24, 49);
            this.score2.Name = "score2";
            this.score2.Size = new System.Drawing.Size(58, 18);
            this.score2.TabIndex = 4;
            this.score2.Text = "Score:";
            // 
            // players2
            // 
            this.players2.AutoSize = true;
            this.players2.Location = new System.Drawing.Point(69, 11);
            this.players2.Name = "players2";
            this.players2.Size = new System.Drawing.Size(102, 18);
            this.players2.TabIndex = 3;
            this.players2.Text = "Name player";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Aqua;
            this.panel3.Controls.Add(this.bank3);
            this.panel3.Controls.Add(this.score3);
            this.panel3.Controls.Add(this.players3);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel3.Location = new System.Drawing.Point(38, 284);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 120);
            this.panel3.TabIndex = 2;
            this.panel3.Visible = false;
            // 
            // bank3
            // 
            this.bank3.AutoSize = true;
            this.bank3.Location = new System.Drawing.Point(21, 85);
            this.bank3.Name = "bank3";
            this.bank3.Size = new System.Drawing.Size(51, 18);
            this.bank3.TabIndex = 8;
            this.bank3.Text = "Bank:";
            // 
            // score3
            // 
            this.score3.AutoSize = true;
            this.score3.Location = new System.Drawing.Point(21, 50);
            this.score3.Name = "score3";
            this.score3.Size = new System.Drawing.Size(58, 18);
            this.score3.TabIndex = 7;
            this.score3.Text = "Score:";
            // 
            // players3
            // 
            this.players3.AutoSize = true;
            this.players3.Location = new System.Drawing.Point(64, 9);
            this.players3.Name = "players3";
            this.players3.Size = new System.Drawing.Size(102, 18);
            this.players3.TabIndex = 6;
            this.players3.Text = "Name player";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Blue;
            this.panel4.Controls.Add(this.bank4);
            this.panel4.Controls.Add(this.score4);
            this.panel4.Controls.Add(this.players4);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.panel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel4.Location = new System.Drawing.Point(533, 284);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 120);
            this.panel4.TabIndex = 3;
            this.panel4.Visible = false;
            // 
            // bank4
            // 
            this.bank4.AutoSize = true;
            this.bank4.Location = new System.Drawing.Point(24, 85);
            this.bank4.Name = "bank4";
            this.bank4.Size = new System.Drawing.Size(51, 18);
            this.bank4.TabIndex = 11;
            this.bank4.Text = "Bank:";
            // 
            // score4
            // 
            this.score4.AutoSize = true;
            this.score4.Location = new System.Drawing.Point(24, 50);
            this.score4.Name = "score4";
            this.score4.Size = new System.Drawing.Size(58, 18);
            this.score4.TabIndex = 10;
            this.score4.Text = "Score:";
            this.score4.Click += new System.EventHandler(this.label11_Click);
            // 
            // players4
            // 
            this.players4.AutoSize = true;
            this.players4.Location = new System.Drawing.Point(60, 9);
            this.players4.Name = "players4";
            this.players4.Size = new System.Drawing.Size(102, 18);
            this.players4.TabIndex = 9;
            this.players4.Text = "Name player";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(337, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 39);
            this.button1.TabIndex = 4;
            this.button1.Text = "Roll";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(337, 117);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 47);
            this.button2.TabIndex = 5;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(331, 193);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 106);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // wturn
            // 
            this.wturn.AutoSize = true;
            this.wturn.Location = new System.Drawing.Point(356, 23);
            this.wturn.Name = "wturn";
            this.wturn.Size = new System.Drawing.Size(46, 17);
            this.wturn.TabIndex = 7;
            this.wturn.Text = "label1";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 458);
            this.Controls.Add(this.wturn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label bank1;
        private System.Windows.Forms.Label score1;
        private System.Windows.Forms.Label players1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label bank2;
        private System.Windows.Forms.Label score2;
        private System.Windows.Forms.Label players2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label bank3;
        private System.Windows.Forms.Label score3;
        private System.Windows.Forms.Label players3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label bank4;
        private System.Windows.Forms.Label score4;
        private System.Windows.Forms.Label players4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label wturn;
    }
}