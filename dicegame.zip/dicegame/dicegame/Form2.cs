﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dicegame
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        Random r = new Random();
        int turn=1;
        int score = 0;
        int ban1=0;
        int ban2=0;
        int ban3=0;
        int ban4=0;
        DialogResult result;

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void players1_Click(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            wturn.Text = turn + " Player's turn.";
            players1.Text = Form1.playern1;
            players2.Text = Form1.playern2;
            players3.Text = Form1.playern3;
            players4.Text = Form1.playern4;
            switch (Form1.plnum)
            {
                case 2:
                    panel2.Visible = true;
                    break;
                case 3:
                    panel3.Visible = true;
                    panel2.Visible = true;
                    break;
                default:
                    panel4.Visible = true;
                    panel3.Visible = true;
                    panel2.Visible = true;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = r.Next(1, 7);
            

            switch (x)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.one;
                    score = 0;
                    switch (turn)
                    {
                        case 1:
                            score1.Text = "Score: " + score;
                            break;
                        case 2:
                            score2.Text = "Score: " + score;
                            break;
                        case 3:
                            score3.Text = "Score: " + score;
                            break;
                        default:
                            score4.Text = "Score: " + score;
                            break;
                    }
                    if (turn == Form1.plnum)
                    {
                        turn = 1;
                    }
                    else
                    {
                        turn += 1;
                    }
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.two;
                    score += 2;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.three;
                    score += 3;
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.four;
                    score += 4;
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.five;
                    score += 5;
                    break;
                default:
                    pictureBox1.Image = Properties.Resources.six;
                    score += 6;
                    break;
            }
            if (score >= Form1.mxscore)
            {
                string win;
                switch (turn)
                {
                    case 1:
                        win = players1.Text + " win!";
                        break;
                    case 2:
                        win = players2.Text + " win!";
                        break;
                    case 3:
                        win = players3.Text + " win!";
                        break;
                    default:
                        win = players4.Text + " win!";
                        break;
                }
                    
                result=MessageBox.Show(win, "Congragulation",
                   MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk);
                if (result == DialogResult.Retry)
                {
                    this.Hide();
                    Form1 fr1 = new Form1();
                    fr1.ShowDialog();
                }
                else
                {
                    this.Close();
                }
            }
            switch (turn)
            {
                case 1:
                    score1.Text = "Score: " + score;
                    button1.BackColor = Color.Red;
                    button2.BackColor = Color.Red;
                    pictureBox1.BackColor = Color.Red;
                    break;
                case 2:
                    score2.Text = "Score: " + score;
                    button1.BackColor = Color.Yellow;
                    button2.BackColor = Color.Yellow;
                    pictureBox1.BackColor = Color.Yellow; ;
                    break;
                case 3:
                    score3.Text = "Score: " + score;
                    button1.BackColor = Color.Aqua;
                    button2.BackColor = Color.Aqua;
                    pictureBox1.BackColor = Color.Aqua;
                    break;
                default:
                    score4.Text = "Score: " + score;
                    button1.BackColor = Color.Blue;
                    button2.BackColor = Color.Blue;
                    pictureBox1.BackColor = Color.Blue;
                    break;
            }
            wturn.Text = turn + " Player's turn.";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            switch(turn)
            {
                case 1:
                    ban1 += score;
                    score = 0;
                    score1.Text = "Score: " + score;
                    bank1.Text = "Bank: " + ban1;
                    break;
                case 2:
                    ban2 += score;
                    score = 0;
                    score2.Text = "Score: " + score;
                    bank2.Text = "Bank: " + ban2;
                    break;
                case 3:
                    ban3 += score;
                    score = 0;
                    score3.Text = "Score: " + score;
                    bank3.Text = "Bank: " + ban3;
                    break;
                default:
                    ban4 += score;
                    score = 0;
                    score4.Text = "Score: " + score;
                    bank4.Text = "Bank: " + ban4;
                    break;

            }
            if (ban1 >= Form1.mxscore || ban2 >= Form1.mxscore || ban3 >= Form1.mxscore || ban4 >= Form1.mxscore )
            {
                string win;
                switch (turn)
                {
                    case 1:
                        win = players1.Text + " win!";
                        break;
                    case 2:
                        win = players2.Text + " win!";
                        break;
                    case 3:
                        win = players3.Text + " win!";
                        break;
                    default:
                        win = players4.Text + " win!";
                        break;
                }

               result= MessageBox.Show(win, "Congragulation",
                   MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk);
                if (result == DialogResult.Retry)
                {
                    this.Hide();
                    Form1 fr1 = new Form1();
                    fr1.ShowDialog();
                }
                else
                {
                    this.Close();
                }
            }
            if (turn == Form1.plnum)
            {
                turn = 1;
            }
            else
            {
                turn += 1;
            }
            switch (turn)
            {
                case 1:
                    button1.BackColor = Color.Red;
                    button2.BackColor = Color.Red;
                    pictureBox1.BackColor = Color.Red;
                    break;
                case 2:
                    button1.BackColor = Color.Yellow;
                    button2.BackColor = Color.Yellow;
                    pictureBox1.BackColor = Color.Yellow; ;
                    break;
                case 3:
                    button1.BackColor = Color.Aqua;
                    button2.BackColor = Color.Aqua;
                    pictureBox1.BackColor = Color.Aqua;
                    break;
                default:
                    button1.BackColor = Color.Blue;
                    button2.BackColor = Color.Blue;
                    pictureBox1.BackColor = Color.Blue;
                    break;
            }
            wturn.Text = turn + " Player's turn.";

        }

    }
}
 