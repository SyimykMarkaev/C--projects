﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace project5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        string file;
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void save_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("savedata.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("ID: " + id.Text);
            sw.WriteLine("SIZE: " + size.Text);
            sw.WriteLine("FLOOR: " + floor.Text);
            sw.WriteLine("AGE: " + age.Text);
            sw.WriteLine("ADRESS: " + adress.Text);
            sw.WriteLine("0"+rooms.Text);
            sw.WriteLine("BathROOMS: " + bathrooms.Text);
            sw.WriteLine(contacttype.Text);
            sw.WriteLine("0"+price.Text);

            if (file == null)
            {
                sw.WriteLine("no photo");
            }
            else
            {
                sw.WriteLine(file);
            } 


            if (checkBox1.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox2.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox3.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox4.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox5.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox6.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox7.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox8.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox9.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox10.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox11.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }
            if (checkBox2.Checked)
            {
                sw.WriteLine("True");
            }
            else
            {
                sw.WriteLine("false");
            }

            sw.WriteLine("Name: " + name.Text);
            sw.WriteLine("Surname: " + surname.Text);
            sw.WriteLine("Dataofbirth: " + birthdata.Text);
            sw.WriteLine("PhoneNumber: " + phnumber.Text);
            sw.WriteLine("Adress: " + adresss.Text);
            sw.WriteLine("Email: " + email.Text);


            sw.WriteLine("**********************");
            checkBox1.Checked = true;
            id.Text = null;
            size.Text = null;
            floor.Text = null;
            age.Text = null;
            adress.Text = null;
            pictureBox1.Image = null;
            rooms.Text = null;
            bathrooms.Text = null;
            contacttype.Text = null;
            price.Text = null;
            name.Text = null;
            birthdata.Text = null;
            surname.Text = null;
            phnumber.Text = null;
            adresss.Text = null;
            email.Text = null;
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            checkBox9.Checked = false;
            checkBox10.Checked = false;
            checkBox11.Checked = false;
            checkBox12.Checked = false;
            sw.Close();
            fs.Close();
            MessageBox.Show("Contact Added");
        }

        private void adress_TextChanged(object sender, EventArgs e)
        {

        }

        private void addnewphoto_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                file = openFileDialog1.FileName;

                pictureBox1.Image = Image.FromFile(file);
            }
        }
    }
}
