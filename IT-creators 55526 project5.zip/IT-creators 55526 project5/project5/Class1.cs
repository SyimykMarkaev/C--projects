﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    public class Contact
    {
        public String id;
        public String size;
        public String floor;
        public String age;
        public string adress;
        public int room;
        public String bathroom;
        public string contacttype;
        public int price;
        public string picturebox1;
        public String checkbox1r;
        public String checkbox2r;
        public String checkbox3r;
        public String checkbox4r;
        public String checkbox5r;
        public String checkbox6r;
        public String checkbox7r;
        public String checkbox8r;
        public String checkbox9r;
        public String checkbox10r;
        public String checkbox11r;
        public String checkbox12r;
        public string name;
        public string surname;
        public String databirth;
        public String phnumber;
        public string email;
        public string adresss;
        public Contact(String cid, String csize, String cfloor, String cage, string cadress, int croom, String cbathroom, string ccontacttype, 
            int cprice,string cpicturebox1,String ccheckbox1r, String ccheckbox2r, String ccheckbox3r, String ccheckbox4r, String ccheckbox5r,
            String ccheckbox6r, String ccheckbox7r, String ccheckbox8r, String ccheckbox9r, String ccheckbox10r, String ccheckbox11r,
            String ccheckbox12r, string cname, string csurname, String cdatabirth,String cphnumber, string cemail, string cadresss)
        {
            id = cid;
            size = csize;
            floor = cfloor;
            age = cage;
            adress = cadress;
            room = croom;
            bathroom = cbathroom;
            contacttype = ccontacttype;
            price = cprice;
            picturebox1 = cpicturebox1;
            checkbox1r = ccheckbox1r;
            checkbox2r = ccheckbox2r;
            checkbox3r = ccheckbox3r;
            checkbox4r = ccheckbox4r;
            checkbox5r = ccheckbox5r;
            checkbox6r = ccheckbox6r;
            checkbox7r = ccheckbox7r;
            checkbox8r = ccheckbox8r;
            checkbox9r = ccheckbox9r;
            checkbox10r = ccheckbox10r;
            checkbox11r = ccheckbox11r;
            checkbox12r = ccheckbox12r;
            name = cname;
            surname = csurname;
            databirth = cdatabirth;
            phnumber = cphnumber;
            email = cemail;
            adresss = cadresss;

        }
    }
}
