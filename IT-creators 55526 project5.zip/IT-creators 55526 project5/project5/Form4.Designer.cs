﻿
namespace project5
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.maxText = new System.Windows.Forms.TextBox();
            this.minText = new System.Windows.Forms.TextBox();
            this.ContactButton = new System.Windows.Forms.RadioButton();
            this.RoomButton = new System.Windows.Forms.RadioButton();
            this.PriceButton = new System.Windows.Forms.RadioButton();
            this.search = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.adresss = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.phnumber = new System.Windows.Forms.Label();
            this.databirth = new System.Windows.Forms.Label();
            this.surname = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.adress = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.Label();
            this.contacttype = new System.Windows.Forms.Label();
            this.bathroom = new System.Windows.Forms.Label();
            this.room = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.Label();
            this.floor = new System.Windows.Forms.Label();
            this.size = new System.Windows.Forms.Label();
            this.idd = new System.Windows.Forms.Label();
            this.count = new System.Windows.Forms.Label();
            this.nextbutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(269, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 32);
            this.label1.TabIndex = 37;
            this.label1.Text = "Search property";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.maxText);
            this.groupBox1.Controls.Add(this.minText);
            this.groupBox1.Controls.Add(this.ContactButton);
            this.groupBox1.Controls.Add(this.RoomButton);
            this.groupBox1.Controls.Add(this.PriceButton);
            this.groupBox1.Controls.Add(this.search);
            this.groupBox1.Location = new System.Drawing.Point(12, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(636, 141);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "search";
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "KGZ +996",
            "PL +48",
            "RUS +799",
            "USA +1 213",
            "KZ +997",
            "UZ +998",
            "UK +2 431"});
            this.comboBox1.Location = new System.Drawing.Point(465, 35);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(142, 24);
            this.comboBox1.TabIndex = 35;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(150, 85);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(125, 22);
            this.textBox3.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "to";
            // 
            // maxText
            // 
            this.maxText.Enabled = false;
            this.maxText.Location = new System.Drawing.Point(218, 35);
            this.maxText.Name = "maxText";
            this.maxText.Size = new System.Drawing.Size(57, 22);
            this.maxText.TabIndex = 5;
            // 
            // minText
            // 
            this.minText.Enabled = false;
            this.minText.Location = new System.Drawing.Point(110, 34);
            this.minText.Name = "minText";
            this.minText.Size = new System.Drawing.Size(62, 22);
            this.minText.TabIndex = 4;
            this.minText.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ContactButton
            // 
            this.ContactButton.AutoSize = true;
            this.ContactButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ContactButton.Location = new System.Drawing.Point(317, 34);
            this.ContactButton.Name = "ContactButton";
            this.ContactButton.Size = new System.Drawing.Size(124, 22);
            this.ContactButton.TabIndex = 3;
            this.ContactButton.TabStop = true;
            this.ContactButton.Text = "Contact type";
            this.ContactButton.UseVisualStyleBackColor = true;
            this.ContactButton.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // RoomButton
            // 
            this.RoomButton.AutoSize = true;
            this.RoomButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.RoomButton.Location = new System.Drawing.Point(24, 85);
            this.RoomButton.Name = "RoomButton";
            this.RoomButton.Size = new System.Drawing.Size(84, 22);
            this.RoomButton.TabIndex = 2;
            this.RoomButton.TabStop = true;
            this.RoomButton.Text = "Rooms";
            this.RoomButton.UseVisualStyleBackColor = true;
            this.RoomButton.CheckedChanged += new System.EventHandler(this.RoomButton_CheckedChanged);
            // 
            // PriceButton
            // 
            this.PriceButton.AutoSize = true;
            this.PriceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PriceButton.Location = new System.Drawing.Point(24, 34);
            this.PriceButton.Name = "PriceButton";
            this.PriceButton.Size = new System.Drawing.Size(68, 22);
            this.PriceButton.TabIndex = 1;
            this.PriceButton.TabStop = true;
            this.PriceButton.Text = "Price";
            this.PriceButton.UseVisualStyleBackColor = true;
            this.PriceButton.CheckedChanged += new System.EventHandler(this.PriceButton_CheckedChanged);
            // 
            // search
            // 
            this.search.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.search.Location = new System.Drawing.Point(448, 97);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(104, 32);
            this.search.TabIndex = 0;
            this.search.Text = "search";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // back
            // 
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.back.Location = new System.Drawing.Point(716, 95);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(104, 32);
            this.back.TabIndex = 1;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.count);
            this.groupBox2.Controls.Add(this.nextbutton);
            this.groupBox2.Controls.Add(this.backbutton);
            this.groupBox2.Location = new System.Drawing.Point(23, 191);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(844, 354);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Property";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.adresss);
            this.groupBox4.Controls.Add(this.email);
            this.groupBox4.Controls.Add(this.phnumber);
            this.groupBox4.Controls.Add(this.databirth);
            this.groupBox4.Controls.Add(this.surname);
            this.groupBox4.Controls.Add(this.name);
            this.groupBox4.Location = new System.Drawing.Point(454, 201);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(384, 131);
            this.groupBox4.TabIndex = 50;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Owner";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // adresss
            // 
            this.adresss.AutoSize = true;
            this.adresss.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.adresss.Location = new System.Drawing.Point(213, 52);
            this.adresss.Name = "adresss";
            this.adresss.Size = new System.Drawing.Size(58, 17);
            this.adresss.TabIndex = 55;
            this.adresss.Text = "Adress";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.email.Location = new System.Drawing.Point(213, 18);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(47, 17);
            this.email.TabIndex = 54;
            this.email.Text = "Email";
            // 
            // phnumber
            // 
            this.phnumber.AutoSize = true;
            this.phnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.phnumber.Location = new System.Drawing.Point(6, 108);
            this.phnumber.Name = "phnumber";
            this.phnumber.Size = new System.Drawing.Size(118, 17);
            this.phnumber.TabIndex = 53;
            this.phnumber.Text = "Phone number ";
            // 
            // databirth
            // 
            this.databirth.AutoSize = true;
            this.databirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.databirth.Location = new System.Drawing.Point(6, 78);
            this.databirth.Name = "databirth";
            this.databirth.Size = new System.Drawing.Size(99, 17);
            this.databirth.TabIndex = 49;
            this.databirth.Text = "Date of birth";
            // 
            // surname
            // 
            this.surname.AutoSize = true;
            this.surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.surname.Location = new System.Drawing.Point(6, 52);
            this.surname.Name = "surname";
            this.surname.Size = new System.Drawing.Size(72, 17);
            this.surname.TabIndex = 48;
            this.surname.Text = "Surname";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.name.Location = new System.Drawing.Point(6, 26);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(49, 17);
            this.name.TabIndex = 47;
            this.name.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.pictureBox1.Location = new System.Drawing.Point(533, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(193, 174);
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel1);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.adress);
            this.groupBox3.Controls.Add(this.price);
            this.groupBox3.Controls.Add(this.contacttype);
            this.groupBox3.Controls.Add(this.bathroom);
            this.groupBox3.Controls.Add(this.room);
            this.groupBox3.Controls.Add(this.age);
            this.groupBox3.Controls.Add(this.floor);
            this.groupBox3.Controls.Add(this.size);
            this.groupBox3.Controls.Add(this.idd);
            this.groupBox3.Location = new System.Drawing.Point(24, 57);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(421, 291);
            this.groupBox3.TabIndex = 48;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Property data";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Location = new System.Drawing.Point(20, 187);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 98);
            this.panel1.TabIndex = 63;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(173, 166);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 18);
            this.label13.TabIndex = 62;
            this.label13.Text = "Options";
            // 
            // adress
            // 
            this.adress.AutoSize = true;
            this.adress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.adress.Location = new System.Drawing.Point(6, 140);
            this.adress.Name = "adress";
            this.adress.Size = new System.Drawing.Size(65, 18);
            this.adress.TabIndex = 52;
            this.adress.Text = "Adress:";
            this.adress.Click += new System.EventHandler(this.label10_Click);
            // 
            // price
            // 
            this.price.AutoSize = true;
            this.price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.price.Location = new System.Drawing.Point(205, 109);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(52, 18);
            this.price.TabIndex = 51;
            this.price.Text = "Price:";
            // 
            // contacttype
            // 
            this.contacttype.AutoSize = true;
            this.contacttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.contacttype.Location = new System.Drawing.Point(205, 83);
            this.contacttype.Name = "contacttype";
            this.contacttype.Size = new System.Drawing.Size(108, 18);
            this.contacttype.TabIndex = 50;
            this.contacttype.Text = "Contact type:";
            // 
            // bathroom
            // 
            this.bathroom.AutoSize = true;
            this.bathroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bathroom.Location = new System.Drawing.Point(205, 57);
            this.bathroom.Name = "bathroom";
            this.bathroom.Size = new System.Drawing.Size(96, 18);
            this.bathroom.TabIndex = 49;
            this.bathroom.Text = "Bathrooms:";
            // 
            // room
            // 
            this.room.AutoSize = true;
            this.room.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.room.Location = new System.Drawing.Point(205, 31);
            this.room.Name = "room";
            this.room.Size = new System.Drawing.Size(68, 18);
            this.room.TabIndex = 48;
            this.room.Text = "Rooms:";
            // 
            // age
            // 
            this.age.AutoSize = true;
            this.age.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.age.Location = new System.Drawing.Point(6, 109);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(41, 18);
            this.age.TabIndex = 47;
            this.age.Text = "Age:";
            // 
            // floor
            // 
            this.floor.AutoSize = true;
            this.floor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.floor.Location = new System.Drawing.Point(6, 83);
            this.floor.Name = "floor";
            this.floor.Size = new System.Drawing.Size(53, 18);
            this.floor.TabIndex = 46;
            this.floor.Text = "Floor:";
            // 
            // size
            // 
            this.size.AutoSize = true;
            this.size.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.size.Location = new System.Drawing.Point(6, 57);
            this.size.Name = "size";
            this.size.Size = new System.Drawing.Size(46, 18);
            this.size.TabIndex = 45;
            this.size.Text = "Size:";
            // 
            // idd
            // 
            this.idd.AutoSize = true;
            this.idd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.idd.Location = new System.Drawing.Point(6, 31);
            this.idd.Name = "idd";
            this.idd.Size = new System.Drawing.Size(29, 18);
            this.idd.TabIndex = 44;
            this.idd.Text = "ID:";
            // 
            // count
            // 
            this.count.AutoSize = true;
            this.count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.count.Location = new System.Drawing.Point(341, 18);
            this.count.Name = "count";
            this.count.Size = new System.Drawing.Size(80, 18);
            this.count.TabIndex = 36;
            this.count.Text = "0 out of 0";
            // 
            // nextbutton
            // 
            this.nextbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nextbutton.Location = new System.Drawing.Point(779, 20);
            this.nextbutton.Name = "nextbutton";
            this.nextbutton.Size = new System.Drawing.Size(41, 29);
            this.nextbutton.TabIndex = 47;
            this.nextbutton.Text = ">>";
            this.nextbutton.UseVisualStyleBackColor = true;
            this.nextbutton.Click += new System.EventHandler(this.button2_Click);
            // 
            // backbutton
            // 
            this.backbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.backbutton.Location = new System.Drawing.Point(3, 20);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(41, 31);
            this.backbutton.TabIndex = 46;
            this.backbutton.Text = "<<";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 563);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.back);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = " ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton ContactButton;
        private System.Windows.Forms.RadioButton RoomButton;
        private System.Windows.Forms.RadioButton PriceButton;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox maxText;
        private System.Windows.Forms.TextBox minText;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label count;
        private System.Windows.Forms.Button nextbutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label adress;
        private System.Windows.Forms.Label price;
        private System.Windows.Forms.Label contacttype;
        private System.Windows.Forms.Label bathroom;
        private System.Windows.Forms.Label room;
        private System.Windows.Forms.Label age;
        private System.Windows.Forms.Label floor;
        private System.Windows.Forms.Label size;
        private System.Windows.Forms.Label idd;
        private System.Windows.Forms.Label databirth;
        private System.Windows.Forms.Label surname;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label adresss;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label phnumber;
        private System.Windows.Forms.Timer timer1;
    }
}