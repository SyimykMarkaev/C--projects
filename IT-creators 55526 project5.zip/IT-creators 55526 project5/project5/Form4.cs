﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace project5
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public static List<object> listdata = new List<object>();
        List<Object> serched = new List<object>();
        int i = 0;
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (ContactButton.Checked)
            {
                comboBox1.Enabled = true;
                comboBox1.Text = "KGZ +996";
            }
            else
            {
                comboBox1.Text = null;
                comboBox1.Enabled = false;
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void search_Click(object sender, EventArgs e)
        {
            serched.Clear();
            if (PriceButton.Checked)
            {
                int mini;
                int maxi;
                if (minText.Text != "")
                {
                    mini = Convert.ToInt32(minText.Text);
                }
                else { mini = 0; }
                if (maxText.Text != "")
                {
                    maxi = Convert.ToInt32(maxText.Text);
                }
                else { maxi = 9999999; }
                for (int i = 0; i < listdata.Count(); i++)
                {
                    Contact contact = (Contact)listdata[i];
                    if (mini <= contact.price && contact.price <= maxi)
                    {
                        serched.Add(contact);
                    }
                }
            }
            else if (ContactButton.Checked)
            {
                string value = comboBox1.Text;
                for (int i = 0; i < listdata.Count(); i++)
                {
                    Contact contact = (Contact)listdata[i];
                    if (value == contact.contacttype)
                    {
                        serched.Add(contact);
                    }
                }
            }
            else if (RoomButton.Checked)
            {
                if (textBox3.Text != "")
                {
                    int roomn = Convert.ToInt32(textBox3.Text);
                    for (int i = 0; i < listdata.Count(); i++)
                    {
                        Contact contact = (Contact)listdata[i];
                        if (roomn == contact.room)
                        {
                            serched.Add(contact);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Any criteria are met");
                }
            }
            if (serched.Count() != 0)
            {
                i = 0;
                Contact contact1 = (Contact)serched[i];
                idd.Text = (contact1.id);
                size.Text = (contact1.size);
                floor.Text = (contact1.floor);
                age.Text = (contact1.age);
                adress.Text = contact1.adress;
                room.Text = Convert.ToString(contact1.room);
                bathroom.Text = (contact1.bathroom);
                contacttype.Text = "Contact Tyoe: "+contact1.contacttype;
                price.Text = "Price: " + (contact1.price);
                if (contact1.picturebox1 != "no photo")
            {
                pictureBox1.Image = Image.FromFile(contact1.picturebox1);
            }
            else
            {
                pictureBox1.Image = null;
            }
                name.Text = contact1.name;
                surname.Text = contact1.surname;
                databirth.Text = (contact1.databirth);
                phnumber.Text = (contact1.phnumber);
                email.Text = contact1.email;
                adresss.Text = contact1.adresss;
                count.Text = "1 out of " + serched.Count();
            }
            else
            {
                MessageBox.Show("List is empty");
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            Form3.datalist.Clear();
            FileStream f = new FileStream("savedata.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(f);
            while (!sr.EndOfStream)
            {
                Form3.datalist.Add(sr.ReadLine());
            }
            sr.Close();
            f.Close();
            if (Form3.datalist.Count() != 0)
            {
                listdata.Clear();
                for (int i = 0; i < (Form3.datalist).Count(); i += 29)
                {
                    Contact contact1 = new Contact((Form3.datalist[i]), (Form3.datalist[i + 1]), (Form3.datalist[i + 2]), (Form3.datalist[i + 3]), Form3.datalist[i + 4],
                        Convert.ToInt32(Form3.datalist[i + 5]), (Form3.datalist[i + 6]), Form3.datalist[i + 7], Convert.ToInt32(Form3.datalist[i + 8]), Form3.datalist[i + 9], (Form3.datalist[i + 10]), (Form3.datalist[i + 11]),
                        (Form3.datalist[i + 12]), (Form3.datalist[i + 13]), (Form3.datalist[i + 14]), (Form3.datalist[i + 15]), (Form3.datalist[i + 16]), (Form3.datalist[i + 17]),
                         (Form3.datalist[i + 18]), (Form3.datalist[i + 19]), (Form3.datalist[i + 20]), (Form3.datalist[i + 21]), Form3.datalist[i + 22], Form3.datalist[i + 23], (Form3.datalist[i + 24]),
                        (Form3.datalist[i + 25]), Form3.datalist[i + 26], Form3.datalist[i + 27]);
                    listdata.Add(contact1);
                }
            }
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PriceButton_CheckedChanged(object sender, EventArgs e)
        {
            if (PriceButton.Checked)
            {
                minText.Enabled = true;
                maxText.Enabled = true;

            }
            else
            {
                minText.Text = "";
                maxText.Text = "";
                minText.Enabled = false;
                maxText.Enabled = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serched.Count() != 0)
            {
                i += 1;
                if (i == listdata.Count())
                {
                    i = 0;
                }
                else if (i == 0)
                {
                    i = listdata.Count();
                }
                if (serched.Count() == 1)
                {
                    i = 0;
                }
                Contact contact1 = (Contact)serched[i];
                idd.Text = (contact1.id);
                size.Text = (contact1.size);
                floor.Text = (contact1.floor);
                age.Text = (contact1.age);
                adress.Text = contact1.adress;
                room.Text = Convert.ToString(contact1.room);
                bathroom.Text = (contact1.bathroom);
                contacttype.Text = "Contact Tyoe: " + contact1.contacttype;
                price.Text = "Price: " + (contact1.price);
                if (contact1.picturebox1 != "no photo")
                {
                    pictureBox1.Image = Image.FromFile(contact1.picturebox1);
                }
                else
                {
                    pictureBox1.Image = null;
                }
                name.Text = contact1.name;
                surname.Text = contact1.surname;
                databirth.Text = (contact1.databirth);
                phnumber.Text = (contact1.phnumber);
                email.Text = contact1.email;
                adresss.Text = contact1.adresss;
                count.Text = Convert.ToString(i + 1) + " out of " + serched.Count();
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (serched.Count() != 0)
            {
                if (i == listdata.Count())
                {
                    i = 0;
                }
                else if (i < 0)
                {
                    i = listdata.Count();
                }
                i -= 1;
                if (serched.Count() == 1)
                {
                    i = 0;
                }
                Contact contact1 = (Contact)serched[i];
                idd.Text = (contact1.id);
                size.Text = (contact1.size);
                floor.Text = (contact1.floor);
                age.Text = (contact1.age);
                adress.Text = contact1.adress;
                room.Text = Convert.ToString(contact1.room);
                bathroom.Text = (contact1.bathroom);
                contacttype.Text = "Contact Tyoe: " + contact1.contacttype;
                price.Text = "Price: " + (contact1.price);
                if (contact1.picturebox1 != "no photo")
                {
                    pictureBox1.Image = Image.FromFile(contact1.picturebox1);
                }
                else
                {
                    pictureBox1.Image = null;
                }
                name.Text = contact1.name;
                surname.Text = contact1.surname;
                databirth.Text = (contact1.databirth);
                phnumber.Text = (contact1.phnumber);
                email.Text = contact1.email;
                adresss.Text = contact1.adresss;
                count.Text = Convert.ToString(i + 1) + " out of " + serched.Count();
            }
            
        }

        private void RoomButton_CheckedChanged(object sender, EventArgs e)
        {
            if (RoomButton.Checked)
            {
                textBox3.Enabled = true;
            }
            else
            {
                textBox3.Text = "";
                textBox3.Enabled=false;
            }
        }
    }
}
