﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace project5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        int i = 0;
        public static List<string> datalist = new List<string>();
        List<object> listdata = Form4.listdata;

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void exitp_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        public void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            datalist.Clear();
            FileStream f = new FileStream("savedata.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(f);
            while (!sr.EndOfStream)
            {
                datalist.Add(sr.ReadLine());
            }
            sr.Close();
            f.Close();
            if (datalist.Count == 0)
            {
                MessageBox.Show("There any contact");
                this.Close();
                Form1 f1 = new Form1();
                f1.Show();


            }
            else
            {
                if (datalist.Count() != 0)
                {
                    Form4.listdata.Clear();
                    for (int i = 0; i < (datalist).Count(); i += 29)
                    {
                        Contact contact1 = new Contact((datalist[i]), (datalist[i + 1]), (datalist[i + 2]), (datalist[i + 3]), datalist[i + 4],
                            Convert.ToInt32(datalist[i + 5]), (datalist[i + 6]), datalist[i + 7], Convert.ToInt32(datalist[i + 8]), datalist[i + 9], (datalist[i + 10]), (datalist[i + 11]),
                            (datalist[i + 12]), (datalist[i + 13]), (datalist[i + 14]), (datalist[i + 15]), (datalist[i + 16]), (datalist[i + 17]),
                             (datalist[i + 18]), (datalist[i + 19]), (datalist[i + 20]), (datalist[i + 21]), datalist[i + 22], datalist[i + 23], (datalist[i + 24]),
                            (datalist[i + 25]), datalist[i + 26], datalist[i + 27]);
                        Form4.listdata.Add(contact1);
                    }
                }
                i = 0;
                Contact contact2 = (Contact)Form4.listdata[i];
                id1.Text = contact2.id;
                size1.Text = contact2.size;
                floor1.Text = contact2.floor;
                age1.Text = contact2.age;
                adress1.Text = contact2.adress;
                room1.Text = Convert.ToString(contact2.room);
                bathroom1.Text = contact2.bathroom;
                contacttype1.Text = "Contact Tyoe: " + contact2.contacttype;
                price1.Text = "Price: "+contact2.price;
                if (contact2.picturebox1 != "no photo")
                {
                    pictureBox1.Image = Image.FromFile(contact2.picturebox1);
                }
                else { pictureBox1.Image = null; }

                if (contact2.checkbox1r != "True")
                {
                    checkBox1r.Checked = true;}
                else
                {
                    checkBox1r.Checked = false;
                }
                if (contact2.checkbox2r == "True")
                {
                    checkBox2r.Checked = true;
                }
                else
                {
                    checkBox2r.Checked = false;
                }
                if (contact2.checkbox3r == "True")
                {
                    checkBox3r.Checked = true;
                }
                else
                {
                    checkBox3r.Checked = false;
                }
                if (contact2.checkbox4r == "True")
                {
                    checkBox4r.Checked = true;
                }
                else
                {
                    checkBox4r.Checked = false;
                }
                if (contact2.checkbox5r == "True")
                {
                    checkBox5r.Checked = true;
                }
                else
                {
                    checkBox5r.Checked = false;
                }
                if (contact2.checkbox6r == "True")
                {
                    checkBox6r.Checked = true;
                }
                else
                {
                    checkBox6r.Checked = false;
                }
                if (contact2.checkbox7r == "True")
                {
                    checkBox7r.Checked = true;
                }
                else
                {
                    checkBox7r.Checked = false;
                }
                if (contact2.checkbox8r == "True")
                {
                    checkBox8r.Checked = true;
                }
                else
                {
                    checkBox8r.Checked = false;
                }
                if (contact2.checkbox9r == "True")
                {
                    checkBox9r.Checked = true;
                }
                else
                {
                    checkBox9r.Checked = false;
                }
                if (contact2.checkbox10r == "True")
                {
                    checkBox10r.Checked = true;
                }
                else
                {
                    checkBox10r.Checked = false;
                }
                if (contact2.checkbox11r == "True")
                {
                    checkBox11r.Checked = true;
                }
                else
                {
                    checkBox11r.Checked = false;
                }
                if (contact2.checkbox12r == "True")
                {
                    checkBox12r.Checked = true;
                }
                else
                {
                    checkBox12r.Checked = false;
                }
                name1.Text = contact2.name;
                surname1.Text = contact2.surname;
                databirth1.Text = contact2.databirth;
                phnumber1.Text = contact2.phnumber;
                email1.Text = contact2.email;
                adresss1.Text = contact2.adresss;
                
            }
        }

        private void adresso_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            i += 1;
            if (i == listdata.Count())
            {
                i = 0;
            }
            else if (i == 0)
            {
                i = listdata.Count();
            }
            
            Contact contact2 = (Contact)Form4.listdata[i];
            id1.Text = contact2.id;
            size1.Text = contact2.size;
            floor1.Text = contact2.floor;
            age1.Text = contact2.age;
            adress1.Text = contact2.adress;
            room1.Text = Convert.ToString(contact2.room);
            bathroom1.Text = contact2.bathroom;
            contacttype1.Text = "Contact Tyoe: " + contact2.contacttype;
            price1.Text = "Price: " + contact2.price;
            if (contact2.picturebox1 != "no photo")
            {
                pictureBox1.Image = Image.FromFile(contact2.picturebox1);
            }
            else { pictureBox1.Image = null; }

            if (contact2.checkbox2r == "True")
            {
                checkBox2r.Checked = true;
            }
            else
            {
                checkBox2r.Checked = false;
            }
            if (contact2.checkbox3r == "True")
            {
                checkBox3r.Checked = true;
            }
            else
            {
                checkBox3r.Checked = false;
            }
            if (contact2.checkbox4r == "True")
            {
                checkBox4r.Checked = true;
            }
            else
            {
                checkBox4r.Checked = false;
            }
            if (contact2.checkbox5r == "True")
            {
                checkBox5r.Checked = true;
            }
            else
            {
                checkBox5r.Checked = false;
            }
            if (contact2.checkbox6r == "True")
            {
                checkBox6r.Checked = true;
            }
            else
            {
                checkBox6r.Checked = false;
            }
            if (contact2.checkbox7r == "True")
            {
                checkBox7r.Checked = true;
            }
            else
            {
                checkBox7r.Checked = false;
            }
            if (contact2.checkbox8r == "True")
            {
                checkBox8r.Checked = true;
            }
            else
            {
                checkBox8r.Checked = false;
            }
            if (contact2.checkbox9r == "True")
            {
                checkBox9r.Checked = true;
            }
            else
            {
                checkBox9r.Checked = false;
            }
            if (contact2.checkbox10r == "True")
            {
                checkBox10r.Checked = true;
            }
            else
            {
                checkBox10r.Checked = false;
            }
            if (contact2.checkbox11r == "True")
            {
                checkBox11r.Checked = true;
            }
            else
            {
                checkBox11r.Checked = false;
            }
            if (contact2.checkbox12r == "True")
            {
                checkBox12r.Checked = true;
            }
            else
            {
                checkBox12r.Checked = false;
            }
            name1.Text = contact2.name;
            surname1.Text = contact2.surname;
            databirth1.Text = contact2.databirth;
            phnumber1.Text = contact2.phnumber;
            email1.Text = contact2.email;
            adresss1.Text = contact2.adresss;
        }

        private void button1_Click(object sender, EventArgs e)
        {           
            if (i == listdata.Count())
            {
                i = 0;
            }
            else if (i == 0)
            {
                i = listdata.Count();
            }
            i -= 1;
            Contact contact2 = (Contact)Form4.listdata[i];
            id1.Text = contact2.id;
            size1.Text = contact2.size;
            floor1.Text = contact2.floor;
            age1.Text = contact2.age;
            adress1.Text = contact2.adress;
            room1.Text = Convert.ToString(contact2.room);
            bathroom1.Text = contact2.bathroom;
            contacttype1.Text = "Contact Tyoe: " + contact2.contacttype;
            price1.Text = "Price: " + contact2.price;
            if (contact2.picturebox1 != "no photo")
            {
                pictureBox1.Image = Image.FromFile(contact2.picturebox1);
            }
            else { pictureBox1.Image = null; }

            if (contact2.checkbox2r == "True")
            {
                checkBox2r.Checked = true;
            }
            else
            {
                checkBox2r.Checked = false;
            }
            if (contact2.checkbox3r == "True")
            {
                checkBox3r.Checked = true;
            }
            else
            {
                checkBox3r.Checked = false;
            }
            if (contact2.checkbox4r == "True")
            {
                checkBox4r.Checked = true;
            }
            else
            {
                checkBox4r.Checked = false;
            }
            if (contact2.checkbox5r == "True")
            {
                checkBox5r.Checked = true;
            }
            else
            {
                checkBox5r.Checked = false;
            }
            if (contact2.checkbox6r == "True")
            {
                checkBox6r.Checked = true;
            }
            else
            {
                checkBox6r.Checked = false;
            }
            if (contact2.checkbox7r == "True")
            {
                checkBox7r.Checked = true;
            }
            else
            {
                checkBox7r.Checked = false;
            }
            if (contact2.checkbox8r == "True")
            {
                checkBox8r.Checked = true;
            }
            else
            {
                checkBox8r.Checked = false;
            }
            if (contact2.checkbox9r == "True")
            {
                checkBox9r.Checked = true;
            }
            else
            {
                checkBox9r.Checked = false;
            }
            if (contact2.checkbox10r == "True")
            {
                checkBox10r.Checked = true;
            }
            else
            {
                checkBox10r.Checked = false;
            }
            if (contact2.checkbox11r == "True")
            {
                checkBox11r.Checked = true;
            }
            else
            {
                checkBox11r.Checked = false;
            }
            if (contact2.checkbox12r == "True")
            {
                checkBox12r.Checked = true;
            }
            else
            {
                checkBox12r.Checked = false;
            }
            name1.Text = contact2.name;
            surname1.Text = contact2.surname;
            databirth1.Text = contact2.databirth;
            phnumber1.Text = contact2.phnumber;
            email1.Text = contact2.email;
            adresss1.Text = contact2.adresss;
        }
    }
}
