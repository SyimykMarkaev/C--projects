﻿
namespace project5
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.checkBox12r = new System.Windows.Forms.CheckBox();
            this.checkBox11r = new System.Windows.Forms.CheckBox();
            this.adresss1 = new System.Windows.Forms.Label();
            this.checkBox10r = new System.Windows.Forms.CheckBox();
            this.email1 = new System.Windows.Forms.Label();
            this.phnumber1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox9r = new System.Windows.Forms.CheckBox();
            this.checkBox8r = new System.Windows.Forms.CheckBox();
            this.databirth1 = new System.Windows.Forms.Label();
            this.surname1 = new System.Windows.Forms.Label();
            this.name1 = new System.Windows.Forms.Label();
            this.checkBox7r = new System.Windows.Forms.CheckBox();
            this.exitp = new System.Windows.Forms.Button();
            this.checkBox6r = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox5r = new System.Windows.Forms.CheckBox();
            this.checkBox4r = new System.Windows.Forms.CheckBox();
            this.checkBox3r = new System.Windows.Forms.CheckBox();
            this.checkBox2r = new System.Windows.Forms.CheckBox();
            this.checkBox1r = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.adress1 = new System.Windows.Forms.Label();
            this.price1 = new System.Windows.Forms.Label();
            this.contacttype1 = new System.Windows.Forms.Label();
            this.bathroom1 = new System.Windows.Forms.Label();
            this.room1 = new System.Windows.Forms.Label();
            this.age1 = new System.Windows.Forms.Label();
            this.floor1 = new System.Windows.Forms.Label();
            this.size1 = new System.Windows.Forms.Label();
            this.id1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // checkBox12r
            // 
            this.checkBox12r.AutoSize = true;
            this.checkBox12r.Enabled = false;
            this.checkBox12r.Location = new System.Drawing.Point(386, 274);
            this.checkBox12r.Name = "checkBox12r";
            this.checkBox12r.Size = new System.Drawing.Size(59, 21);
            this.checkBox12r.TabIndex = 29;
            this.checkBox12r.Text = "Gym";
            this.checkBox12r.UseVisualStyleBackColor = true;
            // 
            // checkBox11r
            // 
            this.checkBox11r.AutoSize = true;
            this.checkBox11r.Enabled = false;
            this.checkBox11r.Location = new System.Drawing.Point(386, 247);
            this.checkBox11r.Name = "checkBox11r";
            this.checkBox11r.Size = new System.Drawing.Size(112, 21);
            this.checkBox11r.TabIndex = 28;
            this.checkBox11r.Text = "Securty desk";
            this.checkBox11r.UseVisualStyleBackColor = true;
            // 
            // adresss1
            // 
            this.adresss1.AutoSize = true;
            this.adresss1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.adresss1.Location = new System.Drawing.Point(410, 114);
            this.adresss1.Name = "adresss1";
            this.adresss1.Size = new System.Drawing.Size(60, 18);
            this.adresss1.TabIndex = 43;
            this.adresss1.Text = "Adress";
            this.adresss1.Click += new System.EventHandler(this.adresso_Click);
            // 
            // checkBox10r
            // 
            this.checkBox10r.AutoSize = true;
            this.checkBox10r.Enabled = false;
            this.checkBox10r.Location = new System.Drawing.Point(386, 220);
            this.checkBox10r.Name = "checkBox10r";
            this.checkBox10r.Size = new System.Drawing.Size(80, 21);
            this.checkBox10r.TabIndex = 27;
            this.checkBox10r.Text = "Balcony";
            this.checkBox10r.UseVisualStyleBackColor = true;
            // 
            // email1
            // 
            this.email1.AutoSize = true;
            this.email1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.email1.Location = new System.Drawing.Point(410, 78);
            this.email1.Name = "email1";
            this.email1.Size = new System.Drawing.Size(50, 18);
            this.email1.TabIndex = 38;
            this.email1.Text = "Email";
            // 
            // phnumber1
            // 
            this.phnumber1.AutoSize = true;
            this.phnumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.phnumber1.Location = new System.Drawing.Point(407, 40);
            this.phnumber1.Name = "phnumber1";
            this.phnumber1.Size = new System.Drawing.Size(122, 18);
            this.phnumber1.TabIndex = 37;
            this.phnumber1.Text = "Phone number ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightGray;
            this.pictureBox1.Location = new System.Drawing.Point(595, 71);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 214);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // checkBox9r
            // 
            this.checkBox9r.AutoSize = true;
            this.checkBox9r.Enabled = false;
            this.checkBox9r.Location = new System.Drawing.Point(272, 274);
            this.checkBox9r.Name = "checkBox9r";
            this.checkBox9r.Size = new System.Drawing.Size(118, 21);
            this.checkBox9r.TabIndex = 26;
            this.checkBox9r.Text = "Inductive stew";
            this.checkBox9r.UseVisualStyleBackColor = true;
            // 
            // checkBox8r
            // 
            this.checkBox8r.AutoSize = true;
            this.checkBox8r.Enabled = false;
            this.checkBox8r.Location = new System.Drawing.Point(272, 247);
            this.checkBox8r.Name = "checkBox8r";
            this.checkBox8r.Size = new System.Drawing.Size(58, 21);
            this.checkBox8r.TabIndex = 25;
            this.checkBox8r.Text = "Pool";
            this.checkBox8r.UseVisualStyleBackColor = true;
            // 
            // databirth1
            // 
            this.databirth1.AutoSize = true;
            this.databirth1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.databirth1.Location = new System.Drawing.Point(20, 114);
            this.databirth1.Name = "databirth1";
            this.databirth1.Size = new System.Drawing.Size(101, 18);
            this.databirth1.TabIndex = 36;
            this.databirth1.Text = "Date of birth";
            // 
            // surname1
            // 
            this.surname1.AutoSize = true;
            this.surname1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.surname1.Location = new System.Drawing.Point(20, 78);
            this.surname1.Name = "surname1";
            this.surname1.Size = new System.Drawing.Size(75, 18);
            this.surname1.TabIndex = 35;
            this.surname1.Text = "Surname";
            // 
            // name1
            // 
            this.name1.AutoSize = true;
            this.name1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.name1.Location = new System.Drawing.Point(20, 40);
            this.name1.Name = "name1";
            this.name1.Size = new System.Drawing.Size(52, 18);
            this.name1.TabIndex = 34;
            this.name1.Text = "Name";
            // 
            // checkBox7r
            // 
            this.checkBox7r.AutoSize = true;
            this.checkBox7r.Enabled = false;
            this.checkBox7r.Location = new System.Drawing.Point(272, 220);
            this.checkBox7r.Name = "checkBox7r";
            this.checkBox7r.Size = new System.Drawing.Size(108, 21);
            this.checkBox7r.TabIndex = 24;
            this.checkBox7r.Text = "Air condition";
            this.checkBox7r.UseVisualStyleBackColor = true;
            // 
            // exitp
            // 
            this.exitp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.exitp.Location = new System.Drawing.Point(336, 515);
            this.exitp.Name = "exitp";
            this.exitp.Size = new System.Drawing.Size(142, 30);
            this.exitp.TabIndex = 40;
            this.exitp.Text = "Exit";
            this.exitp.UseVisualStyleBackColor = true;
            this.exitp.Click += new System.EventHandler(this.exitp_Click);
            // 
            // checkBox6r
            // 
            this.checkBox6r.AutoSize = true;
            this.checkBox6r.Enabled = false;
            this.checkBox6r.Location = new System.Drawing.Point(149, 274);
            this.checkBox6r.Name = "checkBox6r";
            this.checkBox6r.Size = new System.Drawing.Size(91, 21);
            this.checkBox6r.TabIndex = 23;
            this.checkBox6r.Text = "Bath tube";
            this.checkBox6r.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.adresss1);
            this.groupBox2.Controls.Add(this.email1);
            this.groupBox2.Controls.Add(this.phnumber1);
            this.groupBox2.Controls.Add(this.databirth1);
            this.groupBox2.Controls.Add(this.surname1);
            this.groupBox2.Controls.Add(this.name1);
            this.groupBox2.Location = new System.Drawing.Point(8, 343);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(850, 166);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Owner";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.checkBox12r);
            this.groupBox1.Controls.Add(this.checkBox11r);
            this.groupBox1.Controls.Add(this.checkBox10r);
            this.groupBox1.Controls.Add(this.checkBox9r);
            this.groupBox1.Controls.Add(this.checkBox8r);
            this.groupBox1.Controls.Add(this.checkBox7r);
            this.groupBox1.Controls.Add(this.checkBox6r);
            this.groupBox1.Controls.Add(this.checkBox5r);
            this.groupBox1.Controls.Add(this.checkBox4r);
            this.groupBox1.Controls.Add(this.checkBox3r);
            this.groupBox1.Controls.Add(this.checkBox2r);
            this.groupBox1.Controls.Add(this.checkBox1r);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.adress1);
            this.groupBox1.Controls.Add(this.price1);
            this.groupBox1.Controls.Add(this.contacttype1);
            this.groupBox1.Controls.Add(this.bathroom1);
            this.groupBox1.Controls.Add(this.room1);
            this.groupBox1.Controls.Add(this.age1);
            this.groupBox1.Controls.Add(this.floor1);
            this.groupBox1.Controls.Add(this.size1);
            this.groupBox1.Controls.Add(this.id1);
            this.groupBox1.Location = new System.Drawing.Point(2, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(856, 303);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Property";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(787, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 27);
            this.button2.TabIndex = 45;
            this.button2.Text = ">>";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(26, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(41, 27);
            this.button1.TabIndex = 44;
            this.button1.Text = "<<";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox5r
            // 
            this.checkBox5r.AutoSize = true;
            this.checkBox5r.Enabled = false;
            this.checkBox5r.Location = new System.Drawing.Point(149, 247);
            this.checkBox5r.Name = "checkBox5r";
            this.checkBox5r.Size = new System.Drawing.Size(122, 21);
            this.checkBox5r.TabIndex = 22;
            this.checkBox5r.Text = "Hot/Cold water";
            this.checkBox5r.UseVisualStyleBackColor = true;
            // 
            // checkBox4r
            // 
            this.checkBox4r.AutoSize = true;
            this.checkBox4r.Enabled = false;
            this.checkBox4r.Location = new System.Drawing.Point(149, 220);
            this.checkBox4r.Name = "checkBox4r";
            this.checkBox4r.Size = new System.Drawing.Size(82, 21);
            this.checkBox4r.TabIndex = 21;
            this.checkBox4r.Text = "Elevator";
            this.checkBox4r.UseVisualStyleBackColor = true;
            // 
            // checkBox3r
            // 
            this.checkBox3r.AutoSize = true;
            this.checkBox3r.Enabled = false;
            this.checkBox3r.Location = new System.Drawing.Point(29, 274);
            this.checkBox3r.Name = "checkBox3r";
            this.checkBox3r.Size = new System.Drawing.Size(78, 21);
            this.checkBox3r.TabIndex = 20;
            this.checkBox3r.Text = "Internet";
            this.checkBox3r.UseVisualStyleBackColor = true;
            // 
            // checkBox2r
            // 
            this.checkBox2r.AutoSize = true;
            this.checkBox2r.Enabled = false;
            this.checkBox2r.Location = new System.Drawing.Point(29, 247);
            this.checkBox2r.Name = "checkBox2r";
            this.checkBox2r.Size = new System.Drawing.Size(96, 21);
            this.checkBox2r.TabIndex = 19;
            this.checkBox2r.Text = "Withowner";
            this.checkBox2r.UseVisualStyleBackColor = true;
            // 
            // checkBox1r
            // 
            this.checkBox1r.AutoSize = true;
            this.checkBox1r.Enabled = false;
            this.checkBox1r.Location = new System.Drawing.Point(29, 220);
            this.checkBox1r.Name = "checkBox1r";
            this.checkBox1r.Size = new System.Drawing.Size(93, 21);
            this.checkBox1r.TabIndex = 18;
            this.checkBox1r.Text = "Furnished";
            this.checkBox1r.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(244, 199);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 18);
            this.label11.TabIndex = 17;
            this.label11.Text = "Options";
            // 
            // adress1
            // 
            this.adress1.AutoSize = true;
            this.adress1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.adress1.Location = new System.Drawing.Point(26, 174);
            this.adress1.Name = "adress1";
            this.adress1.Size = new System.Drawing.Size(65, 18);
            this.adress1.TabIndex = 8;
            this.adress1.Text = "Adress:";
            // 
            // price1
            // 
            this.price1.AutoSize = true;
            this.price1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.price1.Location = new System.Drawing.Point(302, 137);
            this.price1.Name = "price1";
            this.price1.Size = new System.Drawing.Size(52, 18);
            this.price1.TabIndex = 7;
            this.price1.Text = "Price:";
            // 
            // contacttype1
            // 
            this.contacttype1.AutoSize = true;
            this.contacttype1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.contacttype1.Location = new System.Drawing.Point(302, 111);
            this.contacttype1.Name = "contacttype1";
            this.contacttype1.Size = new System.Drawing.Size(108, 18);
            this.contacttype1.TabIndex = 6;
            this.contacttype1.Text = "Contact type:";
            // 
            // bathroom1
            // 
            this.bathroom1.AutoSize = true;
            this.bathroom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bathroom1.Location = new System.Drawing.Point(302, 85);
            this.bathroom1.Name = "bathroom1";
            this.bathroom1.Size = new System.Drawing.Size(96, 18);
            this.bathroom1.TabIndex = 5;
            this.bathroom1.Text = "Bathrooms:";
            // 
            // room1
            // 
            this.room1.AutoSize = true;
            this.room1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.room1.Location = new System.Drawing.Point(302, 59);
            this.room1.Name = "room1";
            this.room1.Size = new System.Drawing.Size(68, 18);
            this.room1.TabIndex = 4;
            this.room1.Text = "Rooms:";
            // 
            // age1
            // 
            this.age1.AutoSize = true;
            this.age1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.age1.Location = new System.Drawing.Point(26, 137);
            this.age1.Name = "age1";
            this.age1.Size = new System.Drawing.Size(41, 18);
            this.age1.TabIndex = 3;
            this.age1.Text = "Age:";
            // 
            // floor1
            // 
            this.floor1.AutoSize = true;
            this.floor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.floor1.Location = new System.Drawing.Point(26, 111);
            this.floor1.Name = "floor1";
            this.floor1.Size = new System.Drawing.Size(53, 18);
            this.floor1.TabIndex = 2;
            this.floor1.Text = "Floor:";
            // 
            // size1
            // 
            this.size1.AutoSize = true;
            this.size1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.size1.Location = new System.Drawing.Point(26, 85);
            this.size1.Name = "size1";
            this.size1.Size = new System.Drawing.Size(46, 18);
            this.size1.TabIndex = 1;
            this.size1.Text = "Size:";
            // 
            // id1
            // 
            this.id1.AutoSize = true;
            this.id1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id1.Location = new System.Drawing.Point(26, 59);
            this.id1.Name = "id1";
            this.id1.Size = new System.Drawing.Size(29, 18);
            this.id1.TabIndex = 0;
            this.id1.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(278, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 32);
            this.label1.TabIndex = 36;
            this.label1.Text = "List of properties";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 554);
            this.Controls.Add(this.exitp);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox checkBox12r;
        private System.Windows.Forms.CheckBox checkBox11r;
        private System.Windows.Forms.Label adresss1;
        private System.Windows.Forms.CheckBox checkBox10r;
        private System.Windows.Forms.Label email1;
        private System.Windows.Forms.Label phnumber1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox9r;
        private System.Windows.Forms.CheckBox checkBox8r;
        private System.Windows.Forms.Label databirth1;
        private System.Windows.Forms.Label surname1;
        private System.Windows.Forms.Label name1;
        private System.Windows.Forms.CheckBox checkBox7r;
        private System.Windows.Forms.Button exitp;
        private System.Windows.Forms.CheckBox checkBox6r;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox5r;
        private System.Windows.Forms.CheckBox checkBox4r;
        private System.Windows.Forms.CheckBox checkBox3r;
        private System.Windows.Forms.CheckBox checkBox2r;
        private System.Windows.Forms.CheckBox checkBox1r;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label adress1;
        private System.Windows.Forms.Label price1;
        private System.Windows.Forms.Label contacttype1;
        private System.Windows.Forms.Label bathroom1;
        private System.Windows.Forms.Label room1;
        private System.Windows.Forms.Label age1;
        private System.Windows.Forms.Label floor1;
        private System.Windows.Forms.Label size1;
        private System.Windows.Forms.Label id1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
    }
}